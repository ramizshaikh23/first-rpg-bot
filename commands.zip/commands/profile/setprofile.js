const { SlashCommandBuilder} = require('discord.js');
const { Pool } = require('pg');

const dbClient = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'RPG',
    password: 'mitsuki',
    port: 5432
});

module.exports = {
    data: new SlashCommandBuilder()
    .setName('setprofile')
    .setDescription('Sets your profile information.')
    .addStringOption(option => 
        option.setName('name')
        .setDescription('Sets your character\'s name'))
        .addStringOption(option =>
            option.setName('class')
            .setDescription('Sets the class of the profile')
            .setChoices(
				{ name: 'Assassin', value: 'Assassin' },
				{ name: 'Fighter', value: 'Fighter' },
				{ name: 'Knight', value: 'Knight' },
                { name: 'Mage', value: 'Mage' },
                { name: 'Necromancer', value: 'Necromancer' },
                { name: 'Ranger', value: 'Ranger' })),
                async execute(interaction) {
                    const charName = interaction.options.getString('name');
                    const rpgClass = interaction.options.getString('class');
                    await dbClient.query('INSERT INTO userdb (charname, rpgclass) VALUES ($1, $2)', [charName, rpgClass])
                        .then(() => {
                            interaction.reply('Character Created Successfully!');
                        })
                        .catch((error) => {
                            console.error('Error saving character information:', error);
                            interaction.reply('An error occurred while creating your character');
                        });
                },
};